package com.springboot.dao;

import com.springboot.domain.SysLog;

public interface SysLogDao {
	void saveSysLog(SysLog syslog);
}
