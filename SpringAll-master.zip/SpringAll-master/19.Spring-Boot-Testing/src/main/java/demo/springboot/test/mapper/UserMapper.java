package demo.springboot.test.mapper;

import demo.springboot.test.config.MyMapper;
import demo.springboot.test.domain.User;

public interface UserMapper extends MyMapper<User> {
}