package com.springboot.service;

import com.springboot.bean.User;

public interface UserService extends IService<User>{
	
}
